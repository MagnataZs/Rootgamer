package br.com.rootboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Vigia o app em primeiro plano: abre jogo da lista → entra a sessão; sai do jogo → tudo volta. */
class GameService : Service() {

    @Volatile private var ativo = false
    private var fio: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        criarCanal()
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notificacao = Notification.Builder(this, CANAL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Game Turbo ativo")
            .setContentText("Vigiando a sua lista de jogos")
            .setOngoing(true)
            .setContentIntent(abrir)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notificacao, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notificacao)
        }
        if (!ativo) {
            ativo = true
            fio = Thread { laco() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun laco() {
        // Impede o sistema de "dormir" o serviço (não depende da tela de configurações).
        RootShell.run("dumpsys deviceidle whitelist +" + packageName + " 2>/dev/null")
        var jogoAtual: String? = null
        var fora = 0
        try {
            while (ativo) {
                val pkg = Tuner.primeiroPlano()
                Prefs.putStr(this, "fg", pkg ?: "?")
                Prefs.putLng(this, "beat", System.currentTimeMillis())
                // A barra de notificações e o próprio app não contam como "saiu do jogo".
                if (pkg != null && pkg != "com.android.systemui" && pkg != packageName) {
                    if (Prefs.jogos(this).contains(pkg)) {
                        fora = 0
                        if (jogoAtual != pkg) {
                            if (jogoAtual != null) Sessao.sair(this)
                            jogoAtual = pkg
                            Sessao.entrar(this, pkg)
                        }
                    } else if (jogoAtual != null) {
                        fora++
                        if (fora >= 2) {
                            Sessao.sair(this)
                            jogoAtual = null
                            fora = 0
                        }
                    }
                }
                Thread.sleep(3000)
            }
        } catch (e: InterruptedException) {
            // serviço sendo parado
        } finally {
            if (jogoAtual != null) Sessao.sair(this)
        }
    }

    private fun criarCanal() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CANAL, "Game Turbo", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onDestroy() {
        ativo = false
        fio?.interrupt()
        super.onDestroy()
    }

    companion object {
        private const val CANAL = "gameturbo"
    }
}
