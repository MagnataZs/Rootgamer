package br.com.rootboost

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

fun misturar(a: Int, b: Int, t: Float): Int {
    fun m(x: Int, y: Int) = x + ((y - x) * t).toInt()
    return Color.argb(
        m(Color.alpha(a), Color.alpha(b)), m(Color.red(a), Color.red(b)),
        m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b))
    )
}

/** Ícones de traço desenhados em código (grade 24x24), sem imagens. */
class Icone(ctx: Context, private val tipo: String) : View(ctx) {
    var cor: Int = Cores.SUAVE
        set(v) { field = v; invalidate() }

    private val tr = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val pr = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onMeasure(w: Int, h: Int) {
        val t = context.dp(24)
        setMeasuredDimension(t, t)
    }

    override fun onDraw(c: Canvas) {
        tr.color = cor
        pr.color = cor
        c.save()
        val s = width / 24f
        c.scale(s, s)
        when (tipo) {
            "inicio" -> {
                c.drawArc(RectF(3f, 3f, 21f, 21f), 150f, 240f, false, tr)
                c.drawLine(12f, 12f, 16.5f, 7.5f, tr)
                c.drawCircle(12f, 12f, 1.5f, pr)
            }
            "jogos" -> {
                c.drawRoundRect(RectF(2.5f, 7f, 21.5f, 17.5f), 4.5f, 4.5f, tr)
                c.drawLine(7f, 10.2f, 7f, 14.3f, tr)
                c.drawLine(4.95f, 12.25f, 9.05f, 12.25f, tr)
                c.drawCircle(16f, 11.3f, 1f, pr)
                c.drawCircle(18.4f, 13.4f, 1f, pr)
            }
            "modulos" -> {
                c.drawRoundRect(RectF(4f, 4f, 10.5f, 10.5f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(13.5f, 4f, 20f, 10.5f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(4f, 13.5f, 10.5f, 20f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(13.5f, 13.5f, 20f, 20f), 1.8f, 1.8f, tr)
            }
            "ajustes" -> {
                c.drawLine(4f, 6f, 7f, 6f, tr); c.drawLine(11f, 6f, 20f, 6f, tr); c.drawCircle(9f, 6f, 2f, tr)
                c.drawLine(4f, 12f, 13f, 12f, tr); c.drawLine(17f, 12f, 20f, 12f, tr); c.drawCircle(15f, 12f, 2f, tr)
                c.drawLine(4f, 18f, 6f, 18f, tr); c.drawLine(10f, 18f, 20f, 18f, tr); c.drawCircle(8f, 18f, 2f, tr)
            }
            "info" -> {
                c.drawCircle(12f, 12f, 9f, tr)
                c.drawLine(12f, 11f, 12f, 16.5f, tr)
                c.drawCircle(12f, 7.8f, 1f, pr)
            }
            "fechar" -> {
                c.drawLine(6f, 6f, 18f, 18f, tr)
                c.drawLine(18f, 6f, 6f, 18f, tr)
            }
            "raio" -> {
                val p = Path()
                p.moveTo(13.5f, 2.5f); p.lineTo(5.5f, 13.5f); p.lineTo(11f, 13.5f)
                p.lineTo(10f, 21.5f); p.lineTo(18.5f, 10f); p.lineTo(13f, 10f); p.close()
                c.drawPath(p, pr)
            }
        }
        c.restore()
    }
}

/** Medidor em arco com valor no centro. */
class Medidor(ctx: Context) : View(ctx) {
    var rotulo = ""
    var unidade = ""
    private var texto = "—"
    private var cor = Cores.ACENTO
    private var atual = 0f
    private var anim: ValueAnimator? = null

    private val trilha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Cores.LINHA
    }
    private val arco = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Cores.TEXTO
        typeface = FonteMedia
    }
    private val leg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Cores.SUAVE
    }
    private val area = RectF()

    fun definir(frac: Float, valor: String, c: Int = Cores.ACENTO) {
        texto = valor
        cor = c
        val alvo = frac.coerceIn(0f, 1f)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(atual, alvo)
        a.duration = 450
        a.addUpdateListener { atual = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        val tam = if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED) context.dp(88) else MeasureSpec.getSize(w)
        setMeasuredDimension(tam, tam)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val esp = s * 0.07f
        trilha.strokeWidth = esp
        arco.strokeWidth = esp
        arco.color = cor
        area.set(esp, esp, s - esp, s - esp)
        c.drawArc(area, 135f, 270f, false, trilha)
        if (atual > 0.001f) c.drawArc(area, 135f, 270f * atual, false, arco)
        num.textSize = s * 0.26f
        c.drawText(texto, s / 2f, s * 0.57f, num)
        leg.textSize = s * 0.12f
        c.drawText(rotulo, s / 2f, s * 0.34f, leg)
        c.drawText(unidade, s / 2f, s * 0.76f, leg)
    }
}

/** Interruptor próprio (faixa + bolinha animada). */
class Chave(ctx: Context) : View(ctx) {
    var aoMudar: ((Boolean) -> Unit)? = null
    private var marcado = false
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val faixa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bola = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        setOnClickListener {
            definir(!marcado, true)
            aoMudar?.invoke(marcado)
        }
    }

    fun estaMarcado(): Boolean = marcado

    fun somenteExibir() {
        setOnClickListener(null)
        isClickable = false
    }

    fun definir(v: Boolean, animar: Boolean = false) {
        marcado = v
        anim?.cancel()
        if (animar) {
            val a = ValueAnimator.ofFloat(t, if (v) 1f else 0f)
            a.duration = 160
            a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
            anim = a
            a.start()
        } else {
            t = if (v) 1f else 0f
            invalidate()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.dp(46), context.dp(28))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        faixa.color = misturar(0xFF3A3E48.toInt(), Cores.ACENTO, t)
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, faixa)
        val r = h / 2f - context.dp(3)
        val cx = h / 2f + (w - h) * t
        bola.color = misturar(0xFFB4B9C4.toInt(), Color.WHITE, t)
        c.drawCircle(cx, h / 2f, r, bola)
    }
}

/** Controle segmentado (ex.: Economia | Equilibrado | Performance | Gaming). */
class Segmentado(ctx: Context, opcoes: List<String>, sp: Float = 13f) : LinearLayout(ctx) {
    var aoEscolher: ((Int) -> Unit)? = null
    private val itens = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        val d = context.dp(3)
        setPadding(d, d, d, d)
        background = context.forma(Cores.SUPERFICIE2, 14)
        for (i in opcoes.indices) {
            val t = TextView(context)
            t.text = opcoes[i]
            t.textSize = sp
            t.gravity = android.view.Gravity.CENTER
            t.typeface = FonteMedia
            t.setPadding(0, context.dp(10), 0, context.dp(10))
            t.setTextColor(Cores.SUAVE)
            t.setOnClickListener {
                definir(i)
                aoEscolher?.invoke(i)
            }
            addView(t, LayoutParams(0, AUTO, 1f))
            itens.add(t)
        }
    }

    /** Marca a opção i (use -1 para nenhuma). */
    fun definir(i: Int) {
        for (k in itens.indices) {
            val t = itens[k]
            if (k == i) {
                t.background = context.forma(Cores.ACENTO, 11)
                t.setTextColor(Color.WHITE)
            } else {
                t.background = null
                t.setTextColor(Cores.SUAVE)
            }
        }
    }
}
