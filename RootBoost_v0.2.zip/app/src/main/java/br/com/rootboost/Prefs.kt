package br.com.rootboost

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("rootboost", Context.MODE_PRIVATE)

    fun lista(c: Context, k: String): Set<String> =
        HashSet<String>(sp(c).getStringSet(k, emptySet<String>()) ?: emptySet<String>())

    fun setLista(c: Context, k: String, v: Set<String>) {
        sp(c).edit().putStringSet(k, HashSet<String>(v)).apply()
    }

    fun jogos(c: Context): Set<String> = lista(c, "jogos")
    fun setJogos(c: Context, v: Set<String>) = setLista(c, "jogos", v)
    fun protegidos(c: Context): Set<String> = lista(c, "protegidos")

    /** Perfil escolhido pelo usuário (volta para ele quando o jogo fecha). */
    fun base(c: Context): String = sp(c).getString("base", "equilibrado") ?: "equilibrado"
    fun setBase(c: Context, v: String) { sp(c).edit().putString("base", v).apply() }

    /** Perfil realmente aplicado agora. */
    fun aplicado(c: Context): String = sp(c).getString("aplicado", "equilibrado") ?: "equilibrado"
    fun setAplicado(c: Context, v: String) { sp(c).edit().putString("aplicado", v).apply() }

    /** Perfil usado em cada jogo (padrão: Gaming). */
    fun perfilJogo(c: Context, pkg: String): String = str(c, "pj_$pkg", "gaming")
    fun setPerfilJogo(c: Context, pkg: String, v: String) = putStr(c, "pj_$pkg", v)

    fun modAuto(c: Context, id: String): Boolean = bool(c, "ma_$id", false)
    fun setModAuto(c: Context, id: String, v: Boolean) = putBool(c, "ma_$id", v)
    fun modAtivo(c: Context, id: String): Boolean = bool(c, "mo_$id", false)
    fun setModAtivo(c: Context, id: String, v: Boolean) = putBool(c, "mo_$id", v)

    fun turbo(c: Context): Boolean = bool(c, "turbo", false)
    fun setTurbo(c: Context, v: Boolean) = putBool(c, "turbo", v)
    fun overlay(c: Context): Boolean = bool(c, "overlay", false)
    fun setOverlay(c: Context, v: Boolean) = putBool(c, "overlay", v)
    fun painelNoJogo(c: Context): Boolean = bool(c, "painel_jogo", true)
    fun setPainelNoJogo(c: Context, v: Boolean) = putBool(c, "painel_jogo", v)

    fun bool(c: Context, k: String, padrao: Boolean): Boolean = sp(c).getBoolean(k, padrao)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun str(c: Context, k: String, padrao: String): String = sp(c).getString(k, padrao) ?: padrao
    fun putStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun lng(c: Context, k: String, padrao: Long): Long = sp(c).getLong(k, padrao)
    fun putLng(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
}
