package br.com.rootboost

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.util.Locale

/** Painel flutuante com leituras reais (CPU, temperatura, RAM). Arraste para mover. */
class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var painel: TextView? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var ativo = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (painel != null) return START_NOT_STICKY

        val gerente = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = gerente

        val tv = TextView(this)
        tv.text = "RootBoost\nlendo…"
        tv.textSize = 12f
        tv.setTextColor(Cores.TEXTO)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.background = forma(0xE6141A2E.toInt(), 12, Cores.TURBO, 1)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(12)
        params.y = dp(120)

        var ix = 0
        var iy = 0
        var tx = 0f
        var ty = 0f
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = params.x; iy = params.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    params.x = ix + (e.rawX - tx).toInt()
                    params.y = iy + (e.rawY - ty).toInt()
                    gerente.updateViewLayout(v, params)
                }
            }
            true
        }

        gerente.addView(tv, params)
        painel = tv

        ativo = true
        Thread {
            while (ativo) {
                val s = Stats.ler()
                main.post { painel?.text = formatar(s) }
                try {
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun formatar(s: Stats.Leitura?): String {
        if (s == null) return "RootBoost\nsem leitura (root?)"
        val temp = s.temp?.let { String.format(Locale.US, " • %.0f °C", it) } ?: ""
        val perfil = Tuner.perfis.firstOrNull { it.id == Prefs.aplicado(this) }?.nome ?: "—"
        val app = if (Prefs.turbo(this)) "\nApp: " + Prefs.str(this, "fg", "?").takeLast(28) else ""
        return String.format(Locale.US, "%s\nCPU %d MHz%s\nRAM %.1f/%.1f GB%s", perfil, s.cpuMhz, temp, s.ramUsadaMb / 1024f, s.ramTotalMb / 1024f, app)
    }

    override fun onDestroy() {
        ativo = false
        painel?.let { try { wm?.removeView(it) } catch (e: Exception) { } }
        painel = null
        wm = null
        super.onDestroy()
    }
}
