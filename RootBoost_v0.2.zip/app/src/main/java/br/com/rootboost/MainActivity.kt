package br.com.rootboost

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var paginasRaiz: FrameLayout
    private val paginas = ArrayList<View>()
    private val abaIcones = ArrayList<Icone>()
    private val abaTextos = ArrayList<TextView>()

    private lateinit var tvRoot: TextView
    private lateinit var tvTurbo: TextView
    private lateinit var tvJogos: TextView
    private lateinit var medCpu: Medidor
    private lateinit var medTemp: Medidor
    private lateinit var medRam: Medidor
    private lateinit var segPerfil: Segmentado
    private lateinit var tvPerfilDesc: TextView
    private lateinit var listaJogos: LinearLayout
    private lateinit var tvGov: TextView
    private var govs: List<String> = emptyList()

    @Volatile private var lendo = false
    @Volatile private var geracao = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(Cores.FUNDO)
        paginasRaiz = FrameLayout(this)
        raiz.addView(paginasRaiz, LinearLayout.LayoutParams(CHEIO, 0, 1f))
        raiz.addView(barraInferior(), LinearLayout.LayoutParams(CHEIO, AUTO))
        aplicarInsets(raiz)
        setContentView(raiz)

        paginas.add(paginaInicio())
        paginas.add(paginaJogos())
        paginas.add(paginaModulos())
        paginas.add(paginaAjustes())
        for (p in paginas) paginasRaiz.addView(p, FrameLayout.LayoutParams(CHEIO, CHEIO))
        mostrarAba(0)
    }

    // ---- navegação ---------------------------------------------------------

    private fun barraInferior(): View {
        val barra = LinearLayout(this)
        barra.orientation = LinearLayout.HORIZONTAL
        barra.setBackgroundColor(Cores.SUPERFICIE)
        val nomes = listOf("Início", "Jogos", "Módulos", "Ajustes")
        val tipos = listOf("inicio", "jogos", "modulos", "ajustes")
        for (i in nomes.indices) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = android.view.Gravity.CENTER_HORIZONTAL
            item.setPadding(0, dp(10), 0, dp(10))
            val ic = Icone(this, tipos[i])
            val tv = texto(nomes[i], 11f, Cores.SUAVE, true)
            item.addView(ic, LinearLayout.LayoutParams(AUTO, AUTO))
            item.addView(tv, lp(AUTO, AUTO, 2, 0))
            item.setOnClickListener { mostrarAba(i) }
            abaIcones.add(ic)
            abaTextos.add(tv)
            barra.addView(item, LinearLayout.LayoutParams(0, AUTO, 1f))
        }
        return barra
    }

    private fun mostrarAba(i: Int) {
        for (k in paginas.indices) paginas[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in abaIcones.indices) {
            val cor = if (k == i) Cores.ACENTO else Cores.SUAVE
            abaIcones[k].cor = cor
            abaTextos[k].setTextColor(cor)
        }
        if (i == 1) atualizarJogos()
    }

    // ---- páginas -----------------------------------------------------------

    private fun paginaInicio(): View {
        val col = coluna()

        val topo = horizontal()
        topo.addView(texto("Game Turbo", 28f, Cores.TEXTO, true), pesos())
        tvRoot = texto("Verificando…", 12f, Cores.SUAVE, true)
        tvRoot.setPadding(dp(12), dp(6), dp(12), dp(6))
        tvRoot.background = forma(Cores.SUPERFICIE, 20, Cores.LINHA, 1)
        topo.addView(tvRoot)
        col.addView(topo, lp(CHEIO, AUTO, 0, 16))

        // modo automático
        val auto = cartao()
        val l1 = horizontal()
        val bloco = vertical()
        bloco.addView(texto("Modo automático", 17f, Cores.TEXTO, true))
        bloco.addView(
            texto("Aplica o perfil do jogo e os módulos ligados quando um jogo da lista abre. Ao sair, tudo volta ao normal.", 12f, Cores.SUAVE),
            lp(CHEIO, AUTO, 4, 0)
        )
        l1.addView(bloco, pesos())
        val chTurbo = Chave(this)
        chTurbo.definir(Prefs.turbo(this))
        chTurbo.aoMudar = { ligado -> alternarTurbo(ligado) }
        l1.addView(chTurbo, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        auto.addView(l1)
        tvTurbo = texto("", 12f, Cores.ACENTO, true)
        auto.addView(tvTurbo, lp(CHEIO, AUTO, 10, 12))
        val linhaJogos = horizontal()
        linhaJogos.setPadding(dp(14), dp(12), dp(14), dp(12))
        linhaJogos.background = clicavel(Cores.SUPERFICIE2, 12)
        tvJogos = texto("", 14f)
        linhaJogos.addView(tvJogos, pesos())
        linhaJogos.addView(texto("›", 20f, Cores.SUAVE))
        linhaJogos.setOnClickListener { mostrarAba(1) }
        auto.addView(linhaJogos)
        col.addView(auto)

        // medidores
        val painel = cartao()
        painel.addView(texto("Agora", 15f, Cores.TEXTO, true))
        val med = LinearLayout(this)
        med.orientation = LinearLayout.HORIZONTAL
        medCpu = Medidor(this); medCpu.rotulo = "CPU"; medCpu.unidade = "MHz"
        medTemp = Medidor(this); medTemp.rotulo = "Temp."; medTemp.unidade = "°C"
        medRam = Medidor(this); medRam.rotulo = "RAM"; medRam.unidade = "%"
        for (m in listOf(medCpu, medTemp, medRam)) {
            med.addView(m, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        }
        painel.addView(med, lp(CHEIO, AUTO, 8, 0))
        col.addView(painel, lp(CHEIO, AUTO, 14, 0))

        // perfil
        val perfil = cartao()
        perfil.addView(texto("Perfil", 15f, Cores.TEXTO, true))
        segPerfil = Segmentado(this, Tuner.perfis.map { it.nome }, 11.5f)
        segPerfil.aoEscolher = { i -> aplicar(Tuner.perfis[i].id) }
        perfil.addView(segPerfil, lp(CHEIO, AUTO, 10, 0))
        tvPerfilDesc = texto("", 12f, Cores.SUAVE)
        perfil.addView(tvPerfilDesc, lp(CHEIO, AUTO, 10, 0))
        col.addView(perfil, lp(CHEIO, AUTO, 14, 0))

        // atalhos
        col.addView(secao("Atalhos"), lp(CHEIO, AUTO, 22, 8))
        col.addView(
            grade(
                atalho("Limpar RAM", "Libera memória agora") { emBg { Tuner.limparRam() } },
                atalho("Limpeza profunda", "Encerra apps de fundo") { emBg { Tuner.limpezaProfunda(this, null) } }
            ),
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            grade(
                atalho("Otimizar disco", "fstrim em /data") { emBg { Tuner.otimizarArmazenamento() } },
                atalho("Restaurar padrão", "CPU, GPU, tela e módulos") { restaurarPadrao() }
            )
        )
        return rolavel(col)
    }

    private fun paginaJogos(): View {
        val col = coluna()
        col.addView(texto("Jogos", 28f, Cores.TEXTO, true))
        col.addView(texto("Cada jogo pode ter o seu perfil. Toque num jogo para trocar.", 13f, Cores.SUAVE), lp(CHEIO, AUTO, 4, 16))
        col.addView(botao("Adicionar ou remover jogos") {
            startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "jogos"))
        })
        listaJogos = vertical()
        col.addView(listaJogos, lp(CHEIO, AUTO, 16, 0))
        return rolavel(col)
    }

    private fun paginaModulos(): View {
        val col = coluna()
        col.addView(texto("Módulos", 28f, Cores.TEXTO, true))
        col.addView(
            texto(
                "Os módulos ligados entram sozinhos quando um jogo abre e saem quando você fecha. Dentro do jogo, o painel deixa ligar e desligar na hora.",
                13f, Cores.SUAVE
            ),
            lp(CHEIO, AUTO, 4, 16)
        )
        for (m in Modulos.lista) {
            val c = horizontal()
            c.setPadding(dp(16), dp(14), dp(16), dp(14))
            c.background = forma(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
            val txt = vertical()
            txt.addView(texto(m.nome, 15f, Cores.TEXTO, true))
            txt.addView(texto(m.desc, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
            c.addView(txt, pesos())
            val ch = Chave(this)
            ch.definir(Prefs.modAuto(this, m.id))
            ch.aoMudar = { v -> Prefs.setModAuto(this, m.id, v) }
            c.addView(ch, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
            col.addView(c, lp(CHEIO, AUTO, 0, 10))
        }
        col.addView(
            acao("Apps protegidos", "Nunca encerrados pela limpeza profunda.") {
                startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "protegidos"))
            },
            lp(CHEIO, AUTO, 6, 0)
        )
        return rolavel(col)
    }

    private fun paginaAjustes(): View {
        val col = coluna()
        col.addView(texto("Ajustes", 28f, Cores.TEXTO, true))
        col.addView(
            texto("Controle fino do aparelho. Tudo volta ao padrão em \"Restaurar padrão\" ou ao reiniciar.", 13f, Cores.SUAVE),
            lp(CHEIO, AUTO, 4, 8)
        )

        // CPU
        col.addView(secao("CPU"), lp(CHEIO, AUTO, 14, 8))
        val gov = horizontal()
        gov.setPadding(dp(16), dp(14), dp(16), dp(14))
        gov.background = clicavel(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        val blocoGov = vertical()
        blocoGov.addView(texto("Governor", 14f, Cores.TEXTO, true))
        tvGov = texto("Lendo…", 12f, Cores.ACENTO, true)
        blocoGov.addView(tvGov, lp(CHEIO, AUTO, 2, 0))
        gov.addView(blocoGov, pesos())
        gov.addView(texto("›", 20f, Cores.SUAVE))
        gov.setOnClickListener { escolherGovernor() }
        col.addView(gov, lp(CHEIO, AUTO, 0, 10))
        col.addView(
            slider("Frequência mínima", 0, 100, Prefs.lng(this, "cpu_min", 0L).toInt(), { p -> "$p%" }) { p ->
                Prefs.putLng(this, "cpu_min", p.toLong())
                aplicarCpu(null)
            }.first,
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            slider("Frequência máxima", 30, 100, Prefs.lng(this, "cpu_max", 100L).toInt(), { p -> "$p%" }) { p ->
                Prefs.putLng(this, "cpu_max", p.toLong())
                aplicarCpu(null)
            }.first
        )

        // Tela
        col.addView(secao("Tela"), lp(CHEIO, AUTO, 22, 8))
        val cartaoTaxa = cartao()
        cartaoTaxa.addView(texto("Taxa de atualização", 14f, Cores.TEXTO, true))
        val taxas = listOf(0, 60, 90, 120)
        val segTaxa = Segmentado(this, listOf("Auto", "60 Hz", "90 Hz", "120 Hz"), 12f)
        segTaxa.definir(taxas.indexOf(Prefs.lng(this, "taxa_manual", 0L).toInt()))
        segTaxa.aoEscolher = { i ->
            Prefs.putLng(this, "taxa_manual", taxas[i].toLong())
            emBg { Tuner.taxaTela(taxas[i]) }
        }
        cartaoTaxa.addView(segTaxa, lp(CHEIO, AUTO, 10, 0))
        col.addView(cartaoTaxa, lp(CHEIO, AUTO, 0, 10))
        val satInicial = ((Prefs.str(this, "sat", "1.00").toFloatOrNull() ?: 1f) * 100f).toInt().coerceIn(50, 200)
        val sat = slider("Saturação", 50, 200, satInicial, { p -> String.format(Locale.US, "%.2f", p / 100f) }) { p ->
            val v = p / 100f
            Prefs.putStr(this, "sat", String.format(Locale.US, "%.2f", v))
            Thread { Tuner.saturacao(v) }.start()
        }
        col.addView(sat.first)

        // Aplicativo
        col.addView(secao("Aplicativo"), lp(CHEIO, AUTO, 22, 8))
        col.addView(
            linhaChave("Painel dentro do jogo", "Alça na borda da tela com medidores, perfis e módulos.", Prefs.painelNoJogo(this)) { v ->
                Prefs.setPainelNoJogo(this, v)
                if (v) pedirSobreposicao()
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        val ov = Chave(this)
        ov.definir(Prefs.overlay(this) && Settings.canDrawOverlays(this))
        ov.aoMudar = { ligado ->
            if (ligado) {
                if (!Settings.canDrawOverlays(this)) {
                    ov.definir(false, true)
                    pedirSobreposicao()
                } else {
                    Prefs.setOverlay(this, true)
                    startService(Intent(this, OverlayService::class.java))
                }
            } else {
                Prefs.setOverlay(this, false)
                stopService(Intent(this, OverlayService::class.java))
            }
        }
        val linhaOv = horizontal()
        linhaOv.setPadding(dp(16), dp(14), dp(16), dp(14))
        linhaOv.background = forma(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        val txtOv = vertical()
        txtOv.addView(texto("Medidor flutuante", 15f, Cores.TEXTO, true))
        txtOv.addView(texto("Mini painel com CPU, temperatura e RAM, sempre visível.", 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        linhaOv.addView(txtOv, pesos())
        linhaOv.addView(ov, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        col.addView(linhaOv, lp(CHEIO, AUTO, 0, 10))
        col.addView(
            acao("Economia de bateria", "Libera o app da otimização para o Game Turbo não ser encerrado.") {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            acao("Diagnóstico", "Mostra o que o app enxerga no aparelho. Útil para reportar problemas.") { mostrarDiagnostico() },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            acao("Restaurar padrão", "Devolve CPU, GPU, tela e módulos ao normal.") { restaurarPadrao() }
        )
        col.addView(texto("RootBoost 0.3.0", 12f, Cores.SUAVE), lp(CHEIO, AUTO, 20, 0))
        return rolavel(col)
    }

    // ---- ações -------------------------------------------------------------

    private fun alternarTurbo(ligado: Boolean) {
        Prefs.setTurbo(this, ligado)
        if (ligado) {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            if (Prefs.jogos(this).isEmpty()) {
                Toast.makeText(this, "Escolha pelo menos um jogo na aba Jogos.", Toast.LENGTH_LONG).show()
            }
            if (Prefs.painelNoJogo(this)) pedirSobreposicao()
            startForegroundService(Intent(this, GameService::class.java))
        } else {
            stopService(Intent(this, GameService::class.java))
        }
        mostrarTurbo()
    }

    private fun pedirSobreposicao() {
        if (Settings.canDrawOverlays(this)) return
        Toast.makeText(this, "Libere \"Sobrepor a outros apps\" para o painel aparecer no jogo.", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun aplicar(id: String) {
        Prefs.setBase(this, id)
        emBg { Tuner.aplicar(this, id) }
    }

    private fun aplicarCpu(gov: String?) {
        val mn = Prefs.lng(this, "cpu_min", 0L).toInt()
        val mx = Prefs.lng(this, "cpu_max", 100L).toInt()
        emBg { Tuner.cpuManual(this, gov, mn, mx) }
    }

    private fun restaurarPadrao() {
        Prefs.setBase(this, "equilibrado")
        Prefs.putLng(this, "cpu_min", 0L)
        Prefs.putLng(this, "cpu_max", 100L)
        Prefs.putLng(this, "taxa_manual", 0L)
        Prefs.putStr(this, "sat", "1.00")
        emBg {
            for (m in Modulos.lista) {
                if (m.reversivel && Prefs.modAtivo(this, m.id)) Modulos.desligar(this, m.id)
            }
            Tuner.saturacao(1f)
            Tuner.taxaTela(0)
            Tuner.aplicar(this, "equilibrado")
        }
    }

    private fun escolherGovernor() {
        if (govs.isEmpty()) {
            Toast.makeText(this, "Não consegui ler os governors (root?).", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Governor da CPU")
            .setItems(govs.toTypedArray()) { _, i -> aplicarCpu(govs[i]) }
            .show()
    }

    /** Roda o trabalho fora da tela e mostra o resultado num aviso. */
    private fun emBg(trabalho: () -> String) {
        Thread {
            val msg = try {
                trabalho()
            } catch (e: Exception) {
                "Falhou: ${e.message}"
            }
            runOnUiThread {
                if (msg.isNotEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                atualizarTudo()
            }
        }.start()
    }

    private fun atualizarTudo() {
        val aplicado = Prefs.aplicado(this)
        segPerfil.definir(Tuner.perfis.indexOfFirst { it.id == aplicado })
        tvPerfilDesc.text = Tuner.perfis.firstOrNull { it.id == aplicado }?.desc ?: "Ajuste manual em uso."
        atualizarGovernor()
    }

    private fun atualizarGovernor() {
        Thread {
            val info = Tuner.infoCpu()
            runOnUiThread {
                if (info != null) {
                    govs = info.govs
                    tvGov.text = info.gov + " • " + info.minMhz + "–" + info.maxMhz + " MHz"
                } else {
                    tvGov.text = "Sem leitura (root?)"
                }
            }
        }.start()
    }

    private fun atualizarJogos() {
        listaJogos.removeAllViews()
        val pm = packageManager
        val itens = Prefs.jogos(this).map { pkg ->
            val nome = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            Pair(pkg, nome)
        }.sortedBy { it.second.lowercase() }
        if (itens.isEmpty()) {
            listaJogos.addView(texto("Nenhum jogo ainda. Toque em \"Adicionar ou remover jogos\" para escolher.", 13f, Cores.SUAVE))
            return
        }
        for ((pkg, nome) in itens) {
            val linha = horizontal()
            linha.setPadding(dp(14), dp(12), dp(14), dp(12))
            linha.background = clicavel(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
            val ic = ImageView(this)
            try {
                ic.setImageDrawable(pm.getApplicationIcon(pkg))
            } catch (e: Exception) {
                // sem ícone
            }
            linha.addView(ic, LinearLayout.LayoutParams(dp(44), dp(44)))
            val tx = vertical()
            tx.addView(texto(nome, 15f, Cores.TEXTO, true))
            val nomePerfil = Tuner.perfis.firstOrNull { it.id == Prefs.perfilJogo(this, pkg) }?.nome ?: "Gaming"
            tx.addView(texto("Perfil: $nomePerfil", 12f, Cores.ACENTO, true), lp(CHEIO, AUTO, 2, 0))
            linha.addView(tx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
            linha.addView(texto("›", 20f, Cores.SUAVE))
            linha.setOnClickListener { escolherPerfilJogo(pkg, nome) }
            listaJogos.addView(linha, lp(CHEIO, AUTO, 0, 8))
        }
    }

    private fun escolherPerfilJogo(pkg: String, nome: String) {
        val nomes = Tuner.perfis.map { it.nome }.toTypedArray()
        val atual = Tuner.perfis.indexOfFirst { it.id == Prefs.perfilJogo(this, pkg) }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(nome)
            .setSingleChoiceItems(nomes, atual) { d, i ->
                Prefs.setPerfilJogo(this, pkg, Tuner.perfis[i].id)
                d.dismiss()
                atualizarJogos()
            }
            .setNegativeButton("Remover da lista") { _, _ ->
                val s = HashSet<String>(Prefs.jogos(this))
                s.remove(pkg)
                Prefs.setJogos(this, s)
                atualizarJogos()
                tvJogos.text = "Jogos escolhidos: ${s.size}"
            }
            .show()
    }

    private fun mostrarDiagnostico() {
        Toast.makeText(this, "Coletando…", Toast.LENGTH_SHORT).show()
        Thread {
            val txt = Tuner.diagnostico(this)
            runOnUiThread {
                val tv = TextView(this)
                tv.text = txt
                tv.textSize = 11f
                tv.typeface = Typeface.MONOSPACE
                tv.setTextColor(Cores.TEXTO)
                tv.setTextIsSelectable(true)
                tv.setPadding(dp(20), dp(12), dp(20), dp(12))
                val sv = ScrollView(this)
                sv.addView(tv)
                AlertDialog.Builder(this)
                    .setTitle("Diagnóstico")
                    .setView(sv)
                    .setPositiveButton("Copiar") { _, _ ->
                        val cm = getSystemService(ClipboardManager::class.java)
                        cm.setPrimaryClip(ClipData.newPlainText("diagnostico", txt))
                        Toast.makeText(this, "Copiado.", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Fechar", null)
                    .show()
            }
        }.start()
    }

    // ---- ciclo de vida e leituras ------------------------------------------

    override fun onResume() {
        super.onResume()
        tvJogos.text = "Jogos escolhidos: ${Prefs.jogos(this).size}"
        atualizarTudo()
        if (Prefs.turbo(this)) startForegroundService(Intent(this, GameService::class.java))
        if (Prefs.overlay(this) && Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
        lendo = true
        val minha = ++geracao
        Thread {
            val root = RootShell.root()
            runOnUiThread { mostrarRoot(root) }
            while (lendo && minha == geracao) {
                val s = if (root) Stats.ler() else null
                runOnUiThread { mostrarStats(s) }
                try {
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
    }

    override fun onPause() {
        lendo = false
        geracao++
        super.onPause()
    }

    private fun mostrarRoot(root: Boolean) {
        tvRoot.text = if (root) "Root ativo" else "Sem root"
        tvRoot.setTextColor(if (root) Cores.OK else Cores.ERRO)
    }

    private fun mostrarTurbo() {
        val agora = System.currentTimeMillis()
        val batida = Prefs.lng(this, "beat", 0L)
        val app = Prefs.str(this, "fg", "?")
        tvTurbo.text = when {
            !Prefs.turbo(this) -> "Desligado. Ligue o switch para vigiar os jogos."
            Prefs.jogos(this).isEmpty() -> "Ligado, mas nenhum jogo foi escolhido."
            agora - batida > 9000L -> "Ligado, mas o serviço não está respondendo."
            else -> "Vigiando • app atual: $app"
        }
    }

    private fun mostrarStats(s: Stats.Leitura?) {
        mostrarTurbo()
        if (s == null) {
            medCpu.definir(0f, "—")
            medTemp.definir(0f, "—")
            medRam.definir(0f, "—")
            return
        }
        medCpu.definir(if (s.cpuMaxMhz > 0) s.cpuMhz.toFloat() / s.cpuMaxMhz else 0f, s.cpuMhz.toString())
        val t = s.temp
        if (t != null) {
            medTemp.definir(t / 80f, String.format(Locale.US, "%.0f", t), if (t >= 45f) Cores.ERRO else Cores.ACENTO)
        } else {
            medTemp.definir(0f, "—")
        }
        val pct = if (s.ramTotalMb > 0) s.ramUsadaMb * 100 / s.ramTotalMb else 0
        medRam.definir(pct / 100f, pct.toString())
    }

    // ---- peças de interface ------------------------------------------------

    private fun coluna(): LinearLayout {
        val c = vertical()
        c.setPadding(dp(20), dp(20), dp(20), dp(28))
        return c
    }

    private fun rolavel(c: View): ScrollView {
        val s = ScrollView(this)
        s.isVerticalScrollBarEnabled = false
        s.addView(c)
        return s
    }

    private fun pesos() = LinearLayout.LayoutParams(0, AUTO, 1f)

    private fun secao(t: String) = texto(t, 17f, Cores.TEXTO, true)

    private fun acao(titulo: String, sub: String, aoClicar: () -> Unit): LinearLayout {
        val c = vertical()
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = clicavel(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        c.addView(texto(titulo, 15f, Cores.TEXTO, true))
        c.addView(texto(sub, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        c.setOnClickListener { aoClicar() }
        return c
    }

    private fun atalho(titulo: String, sub: String, aoClicar: () -> Unit): LinearLayout {
        val c = vertical()
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.background = clicavel(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        c.addView(texto(titulo, 14f, Cores.TEXTO, true))
        c.addView(texto(sub, 11.5f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        c.setOnClickListener { aoClicar() }
        return c
    }

    private fun grade(a: View, b: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.addView(a, LinearLayout.LayoutParams(0, AUTO, 1f).apply { rightMargin = dp(5) })
        l.addView(b, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(5) })
        return l
    }

    private fun linhaChave(titulo: String, sub: String, inicial: Boolean, aoMudar: (Boolean) -> Unit): LinearLayout {
        val l = horizontal()
        l.setPadding(dp(16), dp(14), dp(16), dp(14))
        l.background = forma(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        val txt = vertical()
        txt.addView(texto(titulo, 15f, Cores.TEXTO, true))
        txt.addView(texto(sub, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        l.addView(txt, pesos())
        val ch = Chave(this)
        ch.definir(inicial)
        ch.aoMudar = aoMudar
        l.addView(ch, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        return l
    }

    private fun slider(
        titulo: String, min: Int, max: Int, inicial: Int,
        formato: (Int) -> String, aoSoltar: (Int) -> Unit
    ): Pair<LinearLayout, SeekBar> {
        val c = vertical()
        c.setPadding(dp(16), dp(14), dp(16), dp(10))
        c.background = forma(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        val topo = horizontal()
        topo.addView(texto(titulo, 14f, Cores.TEXTO, true), pesos())
        val valor = texto(formato(inicial), 13f, Cores.ACENTO, true)
        topo.addView(valor)
        c.addView(topo)
        val barra = SeekBar(this)
        barra.max = max - min
        barra.progress = (inicial - min).coerceIn(0, max - min)
        barra.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, doUsuario: Boolean) { valor.text = formato(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { aoSoltar((s?.progress ?: 0) + min) }
        })
        c.addView(barra, lp(CHEIO, AUTO, 6, 0))
        return Pair(c, barra)
    }
}
