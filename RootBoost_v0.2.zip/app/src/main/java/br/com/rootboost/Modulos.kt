package br.com.rootboost

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs

/** Cada módulo liga e desliga um ajuste do sistema, guardando o valor original para restaurar. */
object Modulos {

    class Modulo(val id: String, val nome: String, val desc: String, val reversivel: Boolean = true)
    class Res(val ok: Boolean, val msg: String)

    val lista = listOf(
        Modulo("toque", "Resposta ao toque", "Reduz o tempo do toque longo e liga o modo jogo do touch, quando o aparelho tiver."),
        Modulo("dnd", "Não perturbe", "Silencia chamadas e notificações enquanto você joga."),
        Modulo("taxa", "Taxa de atualização máxima", "Fixa a maior taxa de quadros que a tela oferece."),
        Modulo("cor", "Cores vivas", "Aumenta a saturação da tela durante o jogo."),
        Modulo("io", "Disco em modo direto", "Troca o escalonador de I/O pelo mais leve disponível."),
        Modulo("ram", "Limpar RAM", "Libera memória ao abrir o jogo.", false),
        Modulo("profunda", "Limpeza profunda", "Encerra apps de terceiros em segundo plano, menos os protegidos.", false)
    )

    private val SEGURO = Regex("[A-Za-z0-9_.,:-]+")
    private val SEGURO_IO = Regex("[A-Za-z0-9_-]+")
    private val CAMINHO = Regex("/sys/block/[A-Za-z0-9_]+/queue")

    private fun semRoot() = Res(false, "Sem acesso root.")

    private fun restaurar(tabela: String, chave: String, valor: String, padrao: String?): String {
        val v = valor.trim()
        return if (v.isNotEmpty() && v != "null" && SEGURO.matches(v)) "settings put $tabela $chave $v"
        else if (padrao != null) "settings put $tabela $chave $padrao"
        else "settings delete $tabela $chave"
    }

    private fun linhaOrig(saida: String): String? =
        saida.lines().firstOrNull { it.startsWith("ORIG|") }?.removePrefix("ORIG|")

    private fun guardar(ctx: Context, id: String, orig: String) {
        Prefs.putStr(ctx, "mo_orig_$id", orig)
        Prefs.setModAtivo(ctx, id, true)
    }

    /** O escalonador de disco volta ao padrão no boot; o flag de "ligado" também precisa voltar. */
    fun reconciliar(ctx: Context) {
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        if (abs(boot - Prefs.lng(ctx, "mod_boot", -1L)) < 60_000L) return
        Prefs.putLng(ctx, "mod_boot", boot)
        Prefs.setModAtivo(ctx, "io", false)
    }

    fun ligar(ctx: Context, id: String, jogo: String?): Res {
        reconciliar(ctx)
        val m = lista.firstOrNull { it.id == id } ?: return Res(false, "Módulo desconhecido.")
        if (m.reversivel && Prefs.modAtivo(ctx, id)) return Res(true, "Já está ligado.")
        return when (id) {
            "toque" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get secure long_press_timeout)|§(cat /proc/touchpanel/game_switch_enable 2>/dev/null)"
settings put secure long_press_timeout 200
[ -f /proc/touchpanel/game_switch_enable ] && echo 1 > /proc/touchpanel/game_switch_enable
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "|")
                Res(true, "Resposta ao toque ligada.")
            }
            "dnd" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global zen_mode)"
settings put global zen_mode 1
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "0")
                Res(true, "Não perturbe ligado.")
            }
            "taxa" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get system min_refresh_rate)|§(settings get system peak_refresh_rate)"
dumpsys display 2>/dev/null | grep -o 'fps=[0-9.]*' | sort -u | sed 's/^/FPS|/'
""")) ?: return semRoot()
                val maximo = s.lines()
                    .filter { it.startsWith("FPS|") }
                    .mapNotNull { it.removePrefix("FPS|fps=").toFloatOrNull() }
                    .filter { it <= 240f }
                    .maxOrNull()
                    ?: return Res(false, "Não consegui descobrir as taxas da tela.")
                val hz = Math.round(maximo)
                RootShell.run("settings put system min_refresh_rate $hz.0; settings put system peak_refresh_rate $hz.0")
                    ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "|")
                Res(true, "Tela em $hz Hz.")
            }
            "cor" -> {
                Tuner.saturacao(1.25f)
                guardar(ctx, id, "")
                Res(true, "Cores vivas ligadas.")
            }
            "io" -> {
                val s = RootShell.run(sh("""
for q in /sys/block/sd[a-z]/queue /sys/block/mmcblk[0-9]/queue /sys/block/nvme[0-9]n[0-9]/queue; do
  [ -f "§q/scheduler" ] || continue
  echo "IO|§q|§(cat §q/scheduler)"
done
""")) ?: return semRoot()
                val sb = StringBuilder()
                val orig = ArrayList<String>()
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] != "IO" || p.size < 3) continue
                    val conteudo = p[2]
                    val atual = Regex("\\[([^\\]]+)\\]").find(conteudo)?.groupValues?.get(1) ?: continue
                    val disp = conteudo.replace("[", "").replace("]", "").trim().split(Regex("\\s+"))
                    val alvo = listOf("none", "noop", "mq-deadline", "deadline").firstOrNull { it in disp } ?: continue
                    if (alvo == atual || !CAMINHO.matches(p[1])) continue
                    sb.append("echo ").append(alvo).append(" > ").append(p[1]).append("/scheduler 2>/dev/null\n")
                    orig.add(p[1] + "=" + atual)
                }
                if (sb.isEmpty()) return Res(false, "Nada para trocar no disco.")
                RootShell.run(sb.toString()) ?: return semRoot()
                guardar(ctx, id, orig.joinToString(";"))
                Res(true, "Disco em modo direto.")
            }
            "ram" -> Res(true, Tuner.limparRam())
            "profunda" -> Res(true, Tuner.limpezaProfunda(ctx, jogo))
            else -> Res(false, "Módulo desconhecido.")
        }
    }

    fun desligar(ctx: Context, id: String): Res {
        val m = lista.firstOrNull { it.id == id } ?: return Res(false, "Módulo desconhecido.")
        if (!m.reversivel) return Res(true, "")
        if (!Prefs.modAtivo(ctx, id)) return Res(true, "Já está desligado.")
        val o = Prefs.str(ctx, "mo_orig_$id", "").split("|")
        val cmd = when (id) {
            "toque" -> {
                val tp = o.getOrElse(1) { "" }.trim()
                restaurar("secure", "long_press_timeout", o.getOrElse(0) { "" }, null) + "\n" +
                    (if (tp == "0" || tp == "1") "[ -f /proc/touchpanel/game_switch_enable ] && echo $tp > /proc/touchpanel/game_switch_enable" else "")
            }
            "dnd" -> restaurar("global", "zen_mode", o.getOrElse(0) { "" }, "0")
            "taxa" -> restaurar("system", "min_refresh_rate", o.getOrElse(0) { "" }, null) + "\n" +
                restaurar("system", "peak_refresh_rate", o.getOrElse(1) { "" }, null)
            "cor" -> {
                Tuner.saturacao(Prefs.str(ctx, "sat", "1.00").toFloatOrNull() ?: 1f)
                ""
            }
            "io" -> {
                val sb = StringBuilder()
                for (par in o[0].split(";")) {
                    val p = par.split("=")
                    if (p.size == 2 && CAMINHO.matches(p[0]) && SEGURO_IO.matches(p[1]))
                        sb.append("echo ").append(p[1]).append(" > ").append(p[0]).append("/scheduler 2>/dev/null\n")
                }
                sb.toString()
            }
            else -> ""
        }
        if (cmd.isNotBlank()) RootShell.run(cmd) ?: return semRoot()
        Prefs.setModAtivo(ctx, id, false)
        return Res(true, m.nome + " desligado.")
    }
}
