package br.com.rootboost

import android.content.Context
import android.content.Intent

/** O que acontece quando um jogo da lista abre e quando fecha. */
object Sessao {

    fun entrar(ctx: Context, pkg: String) {
        Prefs.putStr(ctx, "em_jogo", pkg)
        Prefs.putLng(ctx, "jogo_inicio", System.currentTimeMillis())
        Prefs.putStr(ctx, "jogo_bat0", Stats.bateria(ctx).toString())
        Tuner.aplicar(ctx, Prefs.perfilJogo(ctx, pkg))
        for (m in Modulos.lista) {
            if (Prefs.modAuto(ctx, m.id)) Modulos.ligar(ctx, m.id, pkg)
        }
        if (Prefs.painelNoJogo(ctx)) ctx.startService(Intent(ctx, PainelJogoService::class.java))
    }

    fun sair(ctx: Context) {
        ctx.stopService(Intent(ctx, PainelJogoService::class.java))
        for (m in Modulos.lista) {
            if (m.reversivel && Prefs.modAtivo(ctx, m.id)) Modulos.desligar(ctx, m.id)
        }
        Tuner.aplicar(ctx, Prefs.base(ctx))
        Prefs.putStr(ctx, "em_jogo", "")
    }
}
