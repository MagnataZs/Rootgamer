# RootBoost 0.3

Painel de desempenho com root e Game Turbo. Código-fonte ainda **não compilado nem testado em aparelho**:
se o build der erro, mande o log para corrigir.

## O que tem
- **Início**: modo automático, medidores (CPU, temperatura, RAM), perfis e atalhos.
- **Jogos**: lista de jogos, cada um com o seu perfil.
- **Módulos** (ligam ao abrir o jogo e desligam ao sair): resposta ao toque, não perturbe, taxa de atualização
  máxima, cores vivas, disco em modo direto, limpar RAM, limpeza profunda (com apps protegidos).
- **Ajustes**: governor, frequência mínima/máxima, taxa de atualização, saturação, painel dentro do jogo,
  medidor flutuante, economia de bateria, **Diagnóstico** e restaurar padrão.
- **Painel dentro do jogo**: alça na borda esquerda; toque para abrir (medidores, perfis, módulos, sessão).

## Segurança
- Valores originais guardados (uma vez por boot) e restaurados ao sair do jogo.
- Não desativa limites térmicos. Reiniciar o aparelho também devolve tudo ao padrão.

## Compilar sem PC (GitHub Actions)
Suba este projeto (ou o zip) no repositório. O workflow `.github/workflows/build.yml` gera o APK;
baixe o artefato **RootBoost-debug-apk** na aba Actions.
